from django.contrib import admin
from django.contrib import admin
from .models import Chatbot

admin.site.register(Chatbot)
# Register your models here.
